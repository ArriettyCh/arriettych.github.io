import pandas as pd

def print_regression_equation(table, name):
    coefficients = table[0][0:3]
    cons = table[0][3]
    # 构建回归方程
    # 遍历回归系数和变量名
    for i, (co, var) in enumerate(zip(coefficients, name)):
        try:
            co = float(co)  # 转为浮点数
        except ValueError:
            print(f"\nError: 无法将系数 '{co}' 转换为浮点数")
            continue

        if i == 0:
            if co > 0:
                print(f"{co:.3f} * {var}", end='')
            else:
                print(f"- {abs(co):.3f} * {var}", end='')
        else:
            if co > 0:
                print(f" + {co:.3f} * {var}", end='')
            else:
                print(f" - {abs(co):.3f} * {var}", end='')
    try:
        cons = float(cons)  # 转为浮点数
    except ValueError:
        print(f"\nError: 无法将常数项 '{cons}' 转换为浮点数")
        return
    if cons > 0:
        print(f" + {cons:.3f}")
    else:
        print(f" - {abs(cons):.3f}")
    print()

# 读取数据
# import_data = pd.read_excel('Data/import_data.xlsx')  # 进口额
industry_data = pd.read_excel('Data/industry_data_2.xlsx')  # 产业结构
urbanization_data = pd.read_excel('Data/urbanization_data_2.xlsx')  # 城镇化率
gdp_data = pd.read_excel('Data/gdp_data_2.xlsx')  # 人均GDP
labor_productivity_data = pd.read_excel('Data/labor_productivity_2.xlsx')  # 劳动生产率
population_data = pd.read_excel('Data/population_data_2.xlsx')  # 人口数据

# print("进口额\n", import_data.head())
# print("产业结构\n", industry_data.head())
# print("城镇化率\n", urbanization_data.head())
# print("人均GDP\n", gdp_data.head())
# print("劳动生产率\n", labor_productivity_data.head())
# print("人口数据\n", population_data.head())

# 处理人口数据，将人口数据转化为人均
# population_data = population_data[['省份', 'year', '频度', '常住人口']]

# 处理进口额数据，转化为人均，因为其余变量采用的都是人均或比例的指标
population_data = population_data[['省份', 'year', '常住人口(万人)', '出口总额(亿美元)']]
population_data['export_data'] = population_data['出口总额(亿美元)'] / population_data['常住人口(万人)']
export_data = population_data[['省份', 'year', '出口总额(亿美元)']]
export_data.rename(columns={'省份': '地区'}, inplace=True)
# print(export_data.head())
# print(import_data.head())

# 处理产业结构数据
industry_data = industry_data[industry_data['year'] != 2023]  # 这里之前报错了
industry_data = industry_data[['地区', 'year', '第二产业增加值占GDP比重']]
industry_data = industry_data.rename(columns={'第二产业增加值占GDP比重': '工业化率'})
industry_data['year'] = industry_data['year'].astype(int)
# print(industry_data.head())

# 处理城镇化率数据
urbanization_data = urbanization_data[urbanization_data['year'] != 2023]
urbanization_data = urbanization_data[['地区', 'year', '城镇化率']]
urbanization_data['year'] = urbanization_data['year'].astype(int)
# print(urbanization_data.head())

# 处理人均GDP数据
gdp_data = gdp_data[gdp_data['year'] != 2023]
gdp_data = gdp_data[['id', 'year', '人均GDP']]
gdp_data['year'] = gdp_data['year'].astype(int)
gdp_data.rename(columns={'id': '地区'}, inplace=True)
# print(gdp_data.head())

# 处理劳动生产率数据
labor_productivity_data.rename(columns={'city': '地区'}, inplace=True)
labor_productivity_data = labor_productivity_data[['地区', 'year', '劳动生产率']]
labor_productivity_data['year'] = labor_productivity_data['year'].astype(int)
# print(labor_productivity_data.head())

# 合并数据
panel_data = pd.merge(export_data[['地区', 'year', '出口总额(亿美元)']], industry_data, how='left', on=['地区', 'year'])
panel_data = pd.merge(panel_data, urbanization_data, how='left', on=['地区', 'year'])
panel_data = pd.merge(panel_data, gdp_data, how='left', on=['地区', 'year'])
panel_data = pd.merge(panel_data, labor_productivity_data, how='left', on=['地区', 'year'])

print(panel_data.isnull().sum())  # 检查缺失值
panel_data.dropna(inplace=True)  # 删除含有缺失值的行
panel_data.rename(
    columns={'地区': 'province', '出口总额(亿美元)': 'export_value', '工业化率': 'industry_rate',
             '城镇化率': 'urbanization_rate',
             '人均GDP': 'gdp_per_capita', '劳动生产率': 'labor_productivity'}, inplace=True)  # 重命名列名

dict_province_id = {
    '北京': 1,
    '天津': 2,
    '河北': 3,
    '山西': 4,
    '内蒙古': 5,
    '辽宁': 6,
    '吉林': 7,
    '黑龙江': 8,
    '上海': 9,
    '江苏': 10,
    '浙江': 11,
    '安徽': 12,
    '福建': 13,
    '江西': 14,
    '山东': 15,
    '河南': 16,
    '湖北': 17,
    '湖南': 18,
    '广东': 19,
    '广西': 20,
    '海南': 21,
    '四川': 23,
    '贵州': 24,
    '云南': 25,
    '西藏': 26,
    '陕西': 27,
    '甘肃': 28,
    '青海': 29,
    '宁夏': 30,
    '新疆': 31,
    '重庆': 32
}
panel_data['province_id'] = panel_data['province'].apply(lambda x: dict_province_id[x])

panel_data.set_index(['province_id', 'year'], inplace=True)  # 确保索引的正确
print(panel_data.head())

panel_data.to_csv('panel_data.csv')  # 保存数据

import stata_setup

stata_setup.config("/Applications/Stata/", "mp")  # 调整路径以匹配你的Stata安装路径
from pystata import stata

# 读取处理后的数据
import pandas as pd

panel_data = pd.read_csv('panel_data.csv')
print(panel_data.head())

stata.run("""
clear all
cd "/Users/chen/Desktop/Study/Econometrics/Final_Proj/Code"  // 更改为你电脑上Code文件夹的绝对路径

// 数据导入
import delimited "panel_data.csv", clear
// 删除缺失值
drop if missing(export_value, labor_productivity, gdp_per_capita, industry_rate, urbanization_rate)
// 设置面板数据结构
xtset province_id year
summarize export_value labor_productivity /* gdp_per_capita */ industry_rate urbanization_rate

// 生成对数形式的变量（对变量进行对数处理以缓解异方差性和规模问题）
gen ln_export_value = log(export_value)
gen ln_labor_productivity = log(labor_productivity)
gen ln_industry_rate = log(industry_rate)
gen ln_urbanization_rate = log(urbanization_rate)
gen ln_gdp_per_capita = log(gdp_per_capita)

// 检查对数变量的分布
// histogram ln_export_value, bin(20) title("Log of Import Value Distribution")
// histogram ln_labor_productivity, bin(20) title("Log of Labor Productivity Distribution")

// 模型检验前的多重共线性检验
regress ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate
estat vif  // 检查多重共线性

// 模型估计与回归分析
// (1) 固定效应模型
xtreg ln_labor_productivity L.ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate, fe robust
estimates store fe
""")

stata_fe_result = stata.get_return()

stata.run("""
// (2) 随机效应模型
xtreg ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate, re robust
estimates store re
""")

stata_re_result = stata.get_return()

stata.run("""
// 固定效应与随机效应的 Hausman 检验
xtreg ln_labor_productivity L.ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate, fe
estimates store fe_no_robust

xtreg ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate, re
estimates store re_no_robust

hausman fe_no_robust re_no_robust, sigmamore

// (3) 混合回归模型（OLS）
regress ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate
estimates store ols
""")

stata_ols_result = stata.get_return()

stata.run("""
// GMM
xtabond ln_labor_productivity L.ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate, twostep robust
estimates store gmm

// 异方差性检验
xtreg ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate, re
xttest0   // 面板数据异方差性检测

// 模型设定问题检验
regress ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate
predict yhat, xb
gen yhat2 = yhat^2
regress ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate yhat2
test yhat2  // 检验高阶项的显著性

// 序列相关性检验
xtserial ln_labor_productivity ln_export_value /* ln_gdp_per_capita */ ln_industry_rate ln_urbanization_rate
""")  # 示例Stata命令

table = stata_fe_result['r(table)']
name = ['上期进口额', '工业化率', '城市化率']

print("\n固定效应模型回归结果：\n劳动生产率 = ", end='')
print_regression_equation(table, name)

table = stata_re_result['r(table)']
print("\n随机效应模型回归结果：\n劳动生产率 = ", end='')
print_regression_equation(table, name)