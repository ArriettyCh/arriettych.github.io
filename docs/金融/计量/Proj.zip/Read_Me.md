# Read Me

1. **Stata 版本要求**：不低于 Stata 17

2. **Pystata环境配置**：环境配置视不同操作系统、编译器和 python 环境而异，具体参见[#官方文档](https://www.stata.com/python/pystata18/index.html)。我的操作系统为 macOS 15.0，编译器为 PyCharm，python 版本为 3.12，环境为 Anaconda 3

3. **更改代码中的路径名以运行：**

   - **line 143**

     `stata_setup.config("/Applications/Stata/", "mp")  # 调整路径以匹配你的Stata安装路径`

   - **line 155**

     `cd "/Users/chen/Desktop/Study/Econometrics/Final_Proj/Code"  // 更改为你电脑上Code文件夹的绝对路径`

   